<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
</head>
<body>
    <form action="login.php" method="post">
        <input type="text" name="username" id="">
        <input type="password" name="passwd" id="">
        <input type="submit" value="Login">
    </form>
</body>
</html>