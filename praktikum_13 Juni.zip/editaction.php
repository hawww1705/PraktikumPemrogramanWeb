<?php
   $user = $_POST['username'];
   $paswd = md5(sha1($_POST['paswd']));
   $email = $_POST['email'];
   $nama = $_POST['nama'];
   $id = $_POST['userid'];
   $alamat = $_POST['alamat'];
   $program_studi = $_POST['programstudi'];
   $status = $_POST['status'];

