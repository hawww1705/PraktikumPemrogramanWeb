<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <table border="0">
        <tr>
            <td>nama</td>
            <td>:</td>
            <td><input type="text" name="nama"></td>
        </tr>
        <tr>
            <td>Password</td>
            <td>:</td>
            <td><input type="Password" name="Password"></td>
        </tr>
    </table><br>
    <input type="submit" value="kirim">
</body>
</html>