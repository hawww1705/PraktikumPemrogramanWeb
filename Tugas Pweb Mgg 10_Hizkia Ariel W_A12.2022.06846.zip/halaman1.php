<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman 1</title>
</head>
<body>
    <?php
    session_start();
    if($_SESSION['is logged in'] !=TRUE)
    {
        header("Location: ");
        exit();
    }

    echo $_SESSION['nama'];
    ?>
    <h1>Selamat datang, <?php echo $_SESSION['nama']?></h1>

    <div class="container mt-5">
    <div class="row">
        <div class="col-md-3">
            <h3>Hizkia Ariel W - 06846</h3>
            <ul class="list-group">
                <a href="Beranda TP 5.html" class="list-group-item">Beranda</a>
                <a href="Jadwal Kuliah PT 5.html" class="list-group-item">Jadwal Kuliah</a>
                <a href="Biodata PT 5.html" class="list-group-item">Biodata</a>
                <a href="logout.php" class="list-group-item">logout</a>
            </ul>
        </div>
</body>
</html>