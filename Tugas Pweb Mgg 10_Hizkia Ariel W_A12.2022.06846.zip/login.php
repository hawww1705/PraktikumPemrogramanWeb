<?php
    $username = $_POST["username"];
    $password = $_POST["password"];

    $u = 'A12.2022.06846';
    $p = 'polke001';

    if($username == $u AND $password == $p)
    {
        session_start();
        $_SESSION['nama'] = $username;
        $_SESSION['is logged in'] = TRUE;

        header("Location: Beranda TP 5.html");
    }
    else 
    {
        echo "Username atau password salah";
    }